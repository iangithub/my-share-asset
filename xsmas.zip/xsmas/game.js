// ============================================================
// 音效系統 (Web Audio API + MP3 背景音樂)
// ============================================================
const AudioSystem = {
    ctx: null,
    bgmAudio: null,
    bgmEnabled: true,
    sfxEnabled: true,
    masterVolume: 0.4,

    init() {
        this.ctx = new (window.AudioContext || window.webkitAudioContext)();

        // 初始化 MP3 背景音樂
        this.bgmAudio = new Audio('bgm.mp3');
        this.bgmAudio.loop = true;
        this.bgmAudio.volume = this.masterVolume;
    },

    // 設定主音量 (0-1)
    setVolume(value) {
        this.masterVolume = value;
        if (this.bgmAudio) {
            this.bgmAudio.volume = value;
        }
    },

    // 設定背景音樂開關
    setBGMEnabled(enabled) {
        this.bgmEnabled = enabled;
        if (enabled && gameState.isRunning) {
            this.startBGM();
        } else {
            this.stopBGM();
        }
    },

    // 設定音效開關
    setSFXEnabled(enabled) {
        this.sfxEnabled = enabled;
    },

    // 播放單一音符
    playTone(frequency, duration, type = 'square', volume = 0.3, delay = 0) {
        if (!this.sfxEnabled || !this.ctx) return;

        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();

        osc.type = type;
        osc.frequency.value = frequency;

        const adjustedVolume = volume * this.masterVolume * 2;
        gain.gain.setValueAtTime(adjustedVolume, this.ctx.currentTime + delay);
        gain.gain.exponentialRampToValueAtTime(0.01, this.ctx.currentTime + delay + duration);

        osc.connect(gain);
        gain.connect(this.ctx.destination);

        osc.start(this.ctx.currentTime + delay);
        osc.stop(this.ctx.currentTime + delay + duration);
    },

    // 撿禮物音效 - 輕快上升音
    pickupGift() {
        this.playTone(523, 0.1, 'square', 0.2);      // C5
        this.playTone(659, 0.1, 'square', 0.2, 0.08); // E5
        this.playTone(784, 0.15, 'square', 0.2, 0.16); // G5
    },

    // 送達得分音效 - 歡快的叮咚
    score() {
        this.playTone(784, 0.1, 'square', 0.25);      // G5
        this.playTone(988, 0.1, 'square', 0.25, 0.1); // B5
        this.playTone(1175, 0.2, 'square', 0.25, 0.2); // D6
        this.playTone(1319, 0.3, 'sine', 0.2, 0.3);   // E6
    },

    // 受傷音效 - 低沉下降
    hurt() {
        this.playTone(300, 0.15, 'sawtooth', 0.3);
        this.playTone(200, 0.2, 'sawtooth', 0.25, 0.1);
        this.playTone(150, 0.25, 'sawtooth', 0.2, 0.2);
    },

    // 獲得生命音效 - 魔法音
    gainLife() {
        this.playTone(523, 0.1, 'sine', 0.2);
        this.playTone(659, 0.1, 'sine', 0.2, 0.1);
        this.playTone(784, 0.1, 'sine', 0.2, 0.2);
        this.playTone(1047, 0.3, 'sine', 0.25, 0.3);
        this.playTone(1319, 0.4, 'sine', 0.2, 0.4);
    },

    // 遊戲結束音效
    gameOver() {
        this.playTone(392, 0.3, 'square', 0.25);      // G4
        this.playTone(330, 0.3, 'square', 0.25, 0.3); // E4
        this.playTone(262, 0.5, 'square', 0.25, 0.6); // C4
        this.playTone(196, 0.8, 'sawtooth', 0.2, 0.9); // G3
    },

    // 開始背景音樂 (MP3)
    startBGM() {
        if (!this.bgmEnabled || !this.bgmAudio) return;

        this.bgmAudio.currentTime = 0;
        this.bgmAudio.play().catch(e => {
            console.log('BGM 播放需要使用者互動:', e);
        });
    },

    // 停止背景音樂
    stopBGM() {
        if (this.bgmAudio) {
            this.bgmAudio.pause();
        }
    }
};

// ============================================================
// 地圖設定
// 0 = 建築, 1 = 街道, 2 = 屋子(送禮目標)
// ============================================================
const TILE_SIZE = 50;
const MAP_WIDTH = 16;
const MAP_HEIGHT = 11;
const HOUSE_COUNT = 5;

let MAP_DATA = [];

// ============================================================
// 隨機地圖生成器
// ============================================================
function generateRandomMap() {
    // 初始化全部為建築
    const map = [];
    for (let y = 0; y < MAP_HEIGHT; y++) {
        map[y] = [];
        for (let x = 0; x < MAP_WIDTH; x++) {
            map[y][x] = 0;
        }
    }

    // 使用遞迴分割法生成迷宮街道
    // 先建立主要街道框架

    // 水平主街道
    const mainY = Math.floor(MAP_HEIGHT / 2);
    for (let x = 1; x < MAP_WIDTH - 1; x++) {
        map[mainY][x] = 1;
    }

    // 垂直主街道
    const mainX = Math.floor(MAP_WIDTH / 2);
    for (let y = 1; y < MAP_HEIGHT - 1; y++) {
        map[y][mainX] = 1;
    }

    // 隨機添加額外的水平街道 (2-3條)
    const horizontalStreets = [];
    const hCount = 2 + Math.floor(Math.random() * 2);
    for (let i = 0; i < hCount; i++) {
        let y;
        do {
            y = 1 + Math.floor(Math.random() * (MAP_HEIGHT - 2));
        } while (Math.abs(y - mainY) < 2 || horizontalStreets.includes(y));
        horizontalStreets.push(y);

        // 隨機起點和終點
        const startX = 1;
        const endX = MAP_WIDTH - 2;
        for (let x = startX; x <= endX; x++) {
            map[y][x] = 1;
        }
    }

    // 隨機添加額外的垂直街道 (3-4條)
    const verticalStreets = [];
    const vCount = 3 + Math.floor(Math.random() * 2);
    for (let i = 0; i < vCount; i++) {
        let x;
        do {
            x = 1 + Math.floor(Math.random() * (MAP_WIDTH - 2));
        } while (Math.abs(x - mainX) < 2 || verticalStreets.includes(x));
        verticalStreets.push(x);

        const startY = 1;
        const endY = MAP_HEIGHT - 2;
        for (let y = startY; y <= endY; y++) {
            map[y][x] = 1;
        }
    }

    // 隨機移除一些街道段落，創造更有趣的路徑
    for (let y = 1; y < MAP_HEIGHT - 1; y++) {
        for (let x = 1; x < MAP_WIDTH - 1; x++) {
            if (map[y][x] === 1 && Math.random() < 0.15) {
                // 檢查移除後是否仍然連通
                const neighbors = countRoadNeighbors(map, x, y);
                if (neighbors >= 3) {
                    map[y][x] = 0;
                }
            }
        }
    }

    // 確保地圖連通性 - 使用洪水填充檢查
    ensureConnectivity(map);

    // 放置屋子 (在街道旁邊的建築位置)
    placeHouses(map, HOUSE_COUNT);

    return map;
}

// 計算相鄰的街道數量
function countRoadNeighbors(map, x, y) {
    let count = 0;
    if (y > 0 && map[y-1][x] >= 1) count++;
    if (y < MAP_HEIGHT-1 && map[y+1][x] >= 1) count++;
    if (x > 0 && map[y][x-1] >= 1) count++;
    if (x < MAP_WIDTH-1 && map[y][x+1] >= 1) count++;
    return count;
}

// 確保地圖連通性
function ensureConnectivity(map) {
    // 找到第一個街道格子
    let startX = -1, startY = -1;
    for (let y = 1; y < MAP_HEIGHT - 1 && startX === -1; y++) {
        for (let x = 1; x < MAP_WIDTH - 1; x++) {
            if (map[y][x] === 1) {
                startX = x;
                startY = y;
                break;
            }
        }
    }

    if (startX === -1) return;

    // 洪水填充標記所有連通的格子
    const visited = new Set();
    const queue = [[startX, startY]];
    visited.add(`${startX},${startY}`);

    while (queue.length > 0) {
        const [x, y] = queue.shift();
        const dirs = [[0,-1], [0,1], [-1,0], [1,0]];
        for (const [dx, dy] of dirs) {
            const nx = x + dx;
            const ny = y + dy;
            const key = `${nx},${ny}`;
            if (nx > 0 && nx < MAP_WIDTH-1 && ny > 0 && ny < MAP_HEIGHT-1 &&
                map[ny][nx] === 1 && !visited.has(key)) {
                visited.add(key);
                queue.push([nx, ny]);
            }
        }
    }

    // 連接未連通的街道
    for (let y = 1; y < MAP_HEIGHT - 1; y++) {
        for (let x = 1; x < MAP_WIDTH - 1; x++) {
            if (map[y][x] === 1 && !visited.has(`${x},${y}`)) {
                // 找最近的已連通街道並建立連接
                connectToVisited(map, x, y, visited);
            }
        }
    }
}

// 連接孤立街道到主網絡
function connectToVisited(map, fromX, fromY, visited) {
    // 簡單方法：向四個方向延伸直到碰到已連通的街道
    const dirs = [[0,-1], [0,1], [-1,0], [1,0]];

    for (const [dx, dy] of dirs) {
        let x = fromX + dx;
        let y = fromY + dy;
        const path = [];

        while (x > 0 && x < MAP_WIDTH-1 && y > 0 && y < MAP_HEIGHT-1) {
            if (visited.has(`${x},${y}`)) {
                // 找到連接點，建立路徑
                for (const [px, py] of path) {
                    map[py][px] = 1;
                    visited.add(`${px},${py}`);
                }
                visited.add(`${fromX},${fromY}`);
                return;
            }
            path.push([x, y]);
            x += dx;
            y += dy;
        }
    }
}

// 放置屋子
function placeHouses(map, count) {
    const candidates = [];

    // 找所有適合放屋子的位置（街道格子且旁邊有建築）
    for (let y = 1; y < MAP_HEIGHT - 1; y++) {
        for (let x = 1; x < MAP_WIDTH - 1; x++) {
            if (map[y][x] === 1) {
                // 檢查是否旁邊有建築（看起來像屋子在路邊）
                const hasBuilding = (
                    (y > 0 && map[y-1][x] === 0) ||
                    (y < MAP_HEIGHT-1 && map[y+1][x] === 0) ||
                    (x > 0 && map[y][x-1] === 0) ||
                    (x < MAP_WIDTH-1 && map[y][x+1] === 0)
                );
                if (hasBuilding) {
                    candidates.push({x, y});
                }
            }
        }
    }

    // 隨機選擇位置放置屋子，確保間隔
    const placed = [];
    let attempts = 0;

    while (placed.length < count && attempts < 100 && candidates.length > 0) {
        const idx = Math.floor(Math.random() * candidates.length);
        const pos = candidates[idx];

        // 檢查與其他屋子的距離
        let tooClose = false;
        for (const p of placed) {
            const dist = Math.abs(p.x - pos.x) + Math.abs(p.y - pos.y);
            if (dist < 4) {
                tooClose = true;
                break;
            }
        }

        if (!tooClose) {
            map[pos.y][pos.x] = 2;
            placed.push(pos);
        }

        candidates.splice(idx, 1);
        attempts++;
    }
}

// ============================================================
// 遊戲設定
// ============================================================
const CONFIG = {
    playerSpeed: 3,
    enemyBaseSpeed: 0.7,           // 降低基礎速度
    enemySpeedIncrement: 0.03,     // 每分降低速度成長
    enemySpawnInterval: 8000,      // 增加生成間隔
    maxEnemies: 3,                 // 減少最大敵人數
    giftCount: 2,
    invincibleTime: 2000,          // 增加無敵時間
    knockbackDistance: 100         // 受傷時敵人被擊退距離
};

// ============================================================
// 遊戲狀態
// ============================================================
const gameState = {
    isRunning: false,
    score: 0,
    lives: 5,
    hasGift: false,
    isInvincible: false,
    enemies: [],
    gifts: [],
    houses: [],
    player: null,
    animationId: null,
    enemySpawnTimer: null,
    gameTime: 0,
    lastMoveTime: 0
};

// ============================================================
// DOM 元素
// ============================================================
const elements = {
    gameArea: document.getElementById('game-area'),
    startScreen: document.getElementById('start-screen'),
    gameOverScreen: document.getElementById('game-over-screen'),
    startBtn: document.getElementById('start-btn'),
    restartBtn: document.getElementById('restart-btn'),
    scoreValue: document.getElementById('score-value'),
    finalScore: document.getElementById('final-score'),
    giftIndicator: document.getElementById('gift-indicator'),
    livesContainer: document.getElementById('lives')
};

// ============================================================
// 按鍵狀態
// ============================================================
const keys = {
    ArrowUp: false,
    ArrowDown: false,
    ArrowLeft: false,
    ArrowRight: false,
    w: false,
    a: false,
    s: false,
    d: false,
    W: false,
    A: false,
    S: false,
    D: false
};

// ============================================================
// 工具函數
// ============================================================

// 檢查某格是否可通行
function isWalkable(gridX, gridY) {
    if (gridX < 0 || gridX >= MAP_WIDTH || gridY < 0 || gridY >= MAP_HEIGHT) {
        return false;
    }
    const tile = MAP_DATA[gridY][gridX];
    return tile === 1 || tile === 2 || tile === 3;
}

// 像素座標轉格子座標
function pixelToGrid(x, y) {
    return {
        gridX: Math.floor(x / TILE_SIZE),
        gridY: Math.floor(y / TILE_SIZE)
    };
}

// 格子座標轉像素中心座標
function gridToPixel(gridX, gridY) {
    return {
        x: gridX * TILE_SIZE + TILE_SIZE / 2,
        y: gridY * TILE_SIZE + TILE_SIZE / 2
    };
}

// 取得可通行的街道格子列表
function getWalkableTiles() {
    const tiles = [];
    for (let y = 0; y < MAP_HEIGHT; y++) {
        for (let x = 0; x < MAP_WIDTH; x++) {
            if (isWalkable(x, y)) {
                tiles.push({ gridX: x, gridY: y });
            }
        }
    }
    return tiles;
}

// 取得屋子位置
function getHouseTiles() {
    const tiles = [];
    for (let y = 0; y < MAP_HEIGHT; y++) {
        for (let x = 0; x < MAP_WIDTH; x++) {
            if (MAP_DATA[y][x] === 2) {
                tiles.push({ gridX: x, gridY: y });
            }
        }
    }
    return tiles;
}

// 計算兩點距離
function distance(x1, y1, x2, y2) {
    const dx = x1 - x2;
    const dy = y1 - y2;
    return Math.sqrt(dx * dx + dy * dy);
}

// BFS 尋路 - 找到從 start 到 target 的下一步
function findNextStep(startX, startY, targetX, targetY) {
    const startGrid = pixelToGrid(startX, startY);
    const targetGrid = pixelToGrid(targetX, targetY);

    // 如果已經在同一格，直接朝目標移動
    if (startGrid.gridX === targetGrid.gridX && startGrid.gridY === targetGrid.gridY) {
        return { x: targetX, y: targetY };
    }

    // BFS
    const queue = [[startGrid.gridX, startGrid.gridY, []]];
    const visited = new Set();
    visited.add(`${startGrid.gridX},${startGrid.gridY}`);

    const directions = [
        { dx: 0, dy: -1 }, // 上
        { dx: 0, dy: 1 },  // 下
        { dx: -1, dy: 0 }, // 左
        { dx: 1, dy: 0 }   // 右
    ];

    while (queue.length > 0) {
        const [x, y, path] = queue.shift();

        for (const dir of directions) {
            const nx = x + dir.dx;
            const ny = y + dir.dy;
            const key = `${nx},${ny}`;

            if (!visited.has(key) && isWalkable(nx, ny)) {
                const newPath = [...path, { gridX: nx, gridY: ny }];

                if (nx === targetGrid.gridX && ny === targetGrid.gridY) {
                    // 找到路徑，返回第一步的中心座標
                    if (newPath.length > 0) {
                        return gridToPixel(newPath[0].gridX, newPath[0].gridY);
                    }
                }

                visited.add(key);
                queue.push([nx, ny, newPath]);
            }
        }
    }

    // 找不到路徑，返回當前位置
    return { x: startX, y: startY };
}

// ============================================================
// 渲染地圖
// ============================================================
function renderMap() {
    const mapContainer = document.createElement('div');
    mapContainer.id = 'map-container';

    for (let y = 0; y < MAP_HEIGHT; y++) {
        for (let x = 0; x < MAP_WIDTH; x++) {
            const tile = document.createElement('div');
            tile.className = 'tile';

            const tileType = MAP_DATA[y][x];

            if (tileType === 0) {
                tile.classList.add('tile-building');
                // 非邊界的建築格子顯示聖誕樹
                if (x > 0 && x < MAP_WIDTH - 1 && y > 0 && y < MAP_HEIGHT - 1) {
                    tile.textContent = '🎄';
                }
            } else {
                tile.classList.add('tile-road');
                // 判斷道路方向
                const hasUp = y > 0 && isWalkable(x, y - 1);
                const hasDown = y < MAP_HEIGHT - 1 && isWalkable(x, y + 1);
                const hasLeft = x > 0 && isWalkable(x - 1, y);
                const hasRight = x < MAP_WIDTH - 1 && isWalkable(x + 1, y);

                const verticalCount = (hasUp ? 1 : 0) + (hasDown ? 1 : 0);
                const horizontalCount = (hasLeft ? 1 : 0) + (hasRight ? 1 : 0);

                if (verticalCount > 0 && horizontalCount > 0) {
                    tile.classList.add('road-cross');
                } else if (verticalCount > 0) {
                    tile.classList.add('road-v');
                } else {
                    tile.classList.add('road-h');
                }
            }

            mapContainer.appendChild(tile);
        }
    }

    elements.gameArea.appendChild(mapContainer);
}

// ============================================================
// 建立遊戲物件
// ============================================================
function createGameObject(type, emoji, x, y) {
    const element = document.createElement('div');
    element.className = `game-object ${type}`;
    element.textContent = emoji;
    element.style.left = `${x - 15}px`;
    element.style.top = `${y - 15}px`;
    elements.gameArea.appendChild(element);
    return element;
}

// ============================================================
// 初始化玩家
// ============================================================
function initPlayer() {
    // 在隨機街道位置生成（避開屋子）
    const walkableTiles = [];
    for (let y = 1; y < MAP_HEIGHT - 1; y++) {
        for (let x = 1; x < MAP_WIDTH - 1; x++) {
            if (MAP_DATA[y][x] === 1) {
                walkableTiles.push({ x, y });
            }
        }
    }

    // 隨機選擇一個位置
    const randomTile = walkableTiles[Math.floor(Math.random() * walkableTiles.length)];
    const startPos = gridToPixel(randomTile.x, randomTile.y);

    gameState.player = {
        x: startPos.x,
        y: startPos.y,
        targetX: startPos.x,
        targetY: startPos.y,
        element: createGameObject('player', '🎅', startPos.x, startPos.y)
    };
}

// ============================================================
// 初始化屋子
// ============================================================
function initHouses() {
    gameState.houses = [];
    const houseTiles = getHouseTiles();

    houseTiles.forEach(tile => {
        const pos = gridToPixel(tile.gridX, tile.gridY);
        const house = {
            x: pos.x,
            y: pos.y,
            gridX: tile.gridX,
            gridY: tile.gridY,
            element: createGameObject('house', '🏠', pos.x, pos.y)
        };
        house.element.classList.add('waiting');
        gameState.houses.push(house);
    });
}

// ============================================================
// 初始化禮物
// ============================================================
function initGifts() {
    gameState.gifts = [];
    for (let i = 0; i < CONFIG.giftCount; i++) {
        spawnGift();
    }
}

function spawnGift() {
    const walkableTiles = getWalkableTiles();
    const playerGrid = pixelToGrid(gameState.player.x, gameState.player.y);

    // 過濾掉玩家附近和已有禮物的格子
    const validTiles = walkableTiles.filter(tile => {
        // 不在玩家附近
        if (Math.abs(tile.gridX - playerGrid.gridX) + Math.abs(tile.gridY - playerGrid.gridY) < 3) {
            return false;
        }
        // 不與現有禮物重疊
        for (const gift of gameState.gifts) {
            const giftGrid = pixelToGrid(gift.x, gift.y);
            if (tile.gridX === giftGrid.gridX && tile.gridY === giftGrid.gridY) {
                return false;
            }
        }
        // 不在屋子位置
        if (MAP_DATA[tile.gridY][tile.gridX] === 2) {
            return false;
        }
        return true;
    });

    if (validTiles.length === 0) return;

    const randomTile = validTiles[Math.floor(Math.random() * validTiles.length)];
    const pos = gridToPixel(randomTile.gridX, randomTile.gridY);

    const gift = {
        x: pos.x,
        y: pos.y,
        element: createGameObject('gift', '🎁', pos.x, pos.y)
    };

    gameState.gifts.push(gift);
}

// ============================================================
// 生成敵人
// ============================================================
function spawnEnemy() {
    if (gameState.enemies.length >= CONFIG.maxEnemies) return;

    const walkableTiles = getWalkableTiles();
    const playerGrid = pixelToGrid(gameState.player.x, gameState.player.y);

    // 在離玩家較遠的地方生成
    const validTiles = walkableTiles.filter(tile => {
        const dist = Math.abs(tile.gridX - playerGrid.gridX) + Math.abs(tile.gridY - playerGrid.gridY);
        return dist > 5;
    });

    if (validTiles.length === 0) return;

    const randomTile = validTiles[Math.floor(Math.random() * validTiles.length)];
    const pos = gridToPixel(randomTile.gridX, randomTile.gridY);

    // 速度隨時間緩慢增加，而非分數
    const timeBonus = Math.min(gameState.gameTime / 60000, 1) * 0.3;

    const enemy = {
        x: pos.x,
        y: pos.y,
        speed: CONFIG.enemyBaseSpeed + timeBonus,
        element: createGameObject('enemy', '🐕', pos.x, pos.y)
    };

    enemy.element.classList.add('enemy-spawn');
    setTimeout(() => enemy.element.classList.remove('enemy-spawn'), 500);

    gameState.enemies.push(enemy);
}

// ============================================================
// 玩家移動
// ============================================================
function updatePlayer() {
    const player = gameState.player;
    let dx = 0;
    let dy = 0;

    if (keys.ArrowUp || keys.w || keys.W) dy = -1;
    else if (keys.ArrowDown || keys.s || keys.S) dy = 1;
    else if (keys.ArrowLeft || keys.a || keys.A) dx = -1;
    else if (keys.ArrowRight || keys.d || keys.D) dx = 1;

    if (dx !== 0 || dy !== 0) {
        const newX = player.x + dx * CONFIG.playerSpeed;
        const newY = player.y + dy * CONFIG.playerSpeed;

        // 檢查新位置是否可通行
        const newGrid = pixelToGrid(newX, newY);

        if (isWalkable(newGrid.gridX, newGrid.gridY)) {
            // 確保不會穿過建築物的對角
            const currentGrid = pixelToGrid(player.x, player.y);

            // 只在同一格或相鄰格之間移動
            if (Math.abs(newGrid.gridX - currentGrid.gridX) <= 1 &&
                Math.abs(newGrid.gridY - currentGrid.gridY) <= 1) {
                player.x = newX;
                player.y = newY;
            }
        }
    }

    // 限制在格子範圍內
    player.x = Math.max(TILE_SIZE / 2, Math.min((MAP_WIDTH - 0.5) * TILE_SIZE, player.x));
    player.y = Math.max(TILE_SIZE / 2, Math.min((MAP_HEIGHT - 0.5) * TILE_SIZE, player.y));

    // 更新 DOM
    player.element.style.left = `${player.x - 16}px`;
    player.element.style.top = `${player.y - 16}px`;
}

// ============================================================
// 敵人移動 (使用 BFS 尋路)
// ============================================================
function updateEnemies() {
    const player = gameState.player;

    gameState.enemies.forEach(enemy => {
        // 找到下一步
        const nextStep = findNextStep(enemy.x, enemy.y, player.x, player.y);

        // 朝下一步移動
        const dx = nextStep.x - enemy.x;
        const dy = nextStep.y - enemy.y;
        const dist = Math.sqrt(dx * dx + dy * dy);

        if (dist > 1) {
            enemy.x += (dx / dist) * enemy.speed;
            enemy.y += (dy / dist) * enemy.speed;
        }

        // 更新 DOM
        enemy.element.style.left = `${enemy.x - 14}px`;
        enemy.element.style.top = `${enemy.y - 14}px`;
    });
}

// ============================================================
// 碰撞檢測
// ============================================================
function checkGiftCollision() {
    if (gameState.hasGift) return;

    for (let i = gameState.gifts.length - 1; i >= 0; i--) {
        const gift = gameState.gifts[i];
        const dist = distance(gameState.player.x, gameState.player.y, gift.x, gift.y);

        if (dist < 30) {
            gameState.hasGift = true;
            gift.element.remove();
            gameState.gifts.splice(i, 1);
            updateGiftIndicator();
            gameState.player.element.classList.add('has-gift');
            AudioSystem.pickupGift(); // 撿禮物音效

            // 延遲生成新禮物
            setTimeout(() => {
                if (gameState.isRunning) {
                    spawnGift();
                }
            }, 2000);

            break;
        }
    }
}

function checkHouseCollision() {
    if (!gameState.hasGift) return;

    for (const house of gameState.houses) {
        const dist = distance(gameState.player.x, gameState.player.y, house.x, house.y);

        if (dist < 35) {
            gameState.hasGift = false;
            gameState.score++;
            updateScore();
            updateGiftIndicator();
            gameState.player.element.classList.remove('has-gift');
            showScorePopup(house.x, house.y);
            AudioSystem.score(); // 得分音效

            // 每 10 分生命值 +1
            if (gameState.score % 10 === 0) {
                gainLife();
            }

            break;
        }
    }
}

// 獲得生命值
function gainLife() {
    gameState.lives++;
    updateLives();
    showLifePopup();
    AudioSystem.gainLife(); // 獲得生命音效
}

// 顯示生命值增加提示
function showLifePopup() {
    const popup = document.createElement('div');
    popup.className = 'score-popup life-popup';
    popup.textContent = '❤️ +1';
    popup.style.left = `${gameState.player.x}px`;
    popup.style.top = `${gameState.player.y - 30}px`;
    elements.gameArea.appendChild(popup);
    setTimeout(() => popup.remove(), 1000);
}

function checkEnemyCollision() {
    if (gameState.isInvincible) return;

    for (const enemy of gameState.enemies) {
        const dist = distance(gameState.player.x, gameState.player.y, enemy.x, enemy.y);

        if (dist < 28) {
            takeDamage();
            break;
        }
    }
}

function takeDamage() {
    gameState.lives--;
    updateLives();
    AudioSystem.hurt(); // 受傷音效

    gameState.isInvincible = true;
    gameState.player.element.classList.add('hurt');

    // 擊退所有敵人，避免被包圍
    knockbackEnemies();

    setTimeout(() => {
        gameState.isInvincible = false;
        gameState.player.element.classList.remove('hurt');
    }, CONFIG.invincibleTime);

    if (gameState.lives <= 0) {
        gameOver();
    }
}

// 擊退敵人
function knockbackEnemies() {
    const player = gameState.player;
    const walkableTiles = getWalkableTiles();

    gameState.enemies.forEach(enemy => {
        // 找一個離玩家較遠的隨機位置
        const farTiles = walkableTiles.filter(tile => {
            const pos = gridToPixel(tile.gridX, tile.gridY);
            const dist = distance(player.x, player.y, pos.x, pos.y);
            return dist > 200;
        });

        if (farTiles.length > 0) {
            const randomTile = farTiles[Math.floor(Math.random() * farTiles.length)];
            const newPos = gridToPixel(randomTile.gridX, randomTile.gridY);
            enemy.x = newPos.x;
            enemy.y = newPos.y;
            enemy.element.style.left = `${enemy.x - 14}px`;
            enemy.element.style.top = `${enemy.y - 14}px`;
        }
    });
}

// ============================================================
// UI 更新
// ============================================================
function showScorePopup(x, y) {
    const popup = document.createElement('div');
    popup.className = 'score-popup';
    popup.textContent = '+1';
    popup.style.left = `${x}px`;
    popup.style.top = `${y}px`;
    elements.gameArea.appendChild(popup);
    setTimeout(() => popup.remove(), 1000);
}

function updateScore() {
    elements.scoreValue.textContent = gameState.score;
}

function updateLives() {
    // 動態生成心形，支援超過 5 顆
    elements.livesContainer.innerHTML = '';
    for (let i = 0; i < gameState.lives; i++) {
        const heart = document.createElement('span');
        heart.className = 'heart';
        heart.textContent = '❤️';
        elements.livesContainer.appendChild(heart);
    }
}

function updateGiftIndicator() {
    elements.giftIndicator.textContent = gameState.hasGift ? '🎁' : '❌';
}

// ============================================================
// 雪花效果
// ============================================================
function createSnowflakes() {
    for (let i = 0; i < 20; i++) {
        setTimeout(() => {
            if (!gameState.isRunning) return;
            const snowflake = document.createElement('div');
            snowflake.className = 'snowflake';
            snowflake.textContent = '❄';
            snowflake.style.left = `${Math.random() * 800}px`;
            snowflake.style.animationDuration = `${3 + Math.random() * 4}s`;
            snowflake.style.animationDelay = `${Math.random() * 2}s`;
            elements.gameArea.appendChild(snowflake);

            setTimeout(() => snowflake.remove(), 8000);
        }, i * 500);
    }
}

function snowflakeLoop() {
    if (!gameState.isRunning) return;
    createSnowflakes();
    setTimeout(snowflakeLoop, 10000);
}

// ============================================================
// 遊戲迴圈
// ============================================================
function gameLoop(timestamp) {
    if (!gameState.isRunning) return;

    gameState.gameTime = timestamp;

    updatePlayer();
    updateEnemies();
    checkGiftCollision();
    checkHouseCollision();
    checkEnemyCollision();

    gameState.animationId = requestAnimationFrame(gameLoop);
}

// ============================================================
// 開始遊戲
// ============================================================
function startGame() {
    // 初始化音效系統
    if (!AudioSystem.ctx) {
        AudioSystem.init();
    }

    // 重置狀態
    gameState.isRunning = true;
    gameState.score = 0;
    gameState.lives = 5;
    gameState.hasGift = false;
    gameState.isInvincible = false;
    gameState.enemies = [];
    gameState.gifts = [];
    gameState.houses = [];
    gameState.gameTime = 0;

    // 清除遊戲區域
    elements.gameArea.innerHTML = '';

    // 生成隨機地圖
    MAP_DATA = generateRandomMap();

    // 渲染地圖
    renderMap();

    // 初始化遊戲物件
    initPlayer();
    initHouses();
    initGifts();

    // 更新 UI
    updateScore();
    updateLives();
    updateGiftIndicator();

    // 隱藏覆蓋畫面
    elements.startScreen.classList.add('hidden');
    elements.gameOverScreen.classList.add('hidden');

    // 開始敵人生成
    setTimeout(() => spawnEnemy(), 2000); // 延遲第一隻敵人
    gameState.enemySpawnTimer = setInterval(() => {
        if (gameState.isRunning) {
            spawnEnemy();
        }
    }, CONFIG.enemySpawnInterval);

    // 開始雪花效果
    snowflakeLoop();

    // 開始背景音樂
    AudioSystem.startBGM();

    // 開始遊戲迴圈
    requestAnimationFrame(gameLoop);
}

// ============================================================
// 遊戲結束
// ============================================================
function gameOver() {
    gameState.isRunning = false;
    AudioSystem.stopBGM(); // 停止背景音樂
    AudioSystem.gameOver(); // 遊戲結束音效

    if (gameState.enemySpawnTimer) {
        clearInterval(gameState.enemySpawnTimer);
    }

    if (gameState.animationId) {
        cancelAnimationFrame(gameState.animationId);
    }

    elements.finalScore.textContent = gameState.score;
    elements.gameOverScreen.classList.remove('hidden');
}

// ============================================================
// 事件監聽
// ============================================================
document.addEventListener('keydown', (e) => {
    if (keys.hasOwnProperty(e.key)) {
        keys[e.key] = true;
        e.preventDefault();
    }
});

document.addEventListener('keyup', (e) => {
    if (keys.hasOwnProperty(e.key)) {
        keys[e.key] = false;
    }
});

elements.startBtn.addEventListener('click', startGame);
elements.restartBtn.addEventListener('click', startGame);

// 設定面板控制
const bgmToggle = document.getElementById('bgm-toggle');
const sfxToggle = document.getElementById('sfx-toggle');
const volumeSlider = document.getElementById('volume-slider');
const volumeValue = document.getElementById('volume-value');

// 背景音樂開關
bgmToggle.addEventListener('change', () => {
    AudioSystem.setBGMEnabled(bgmToggle.checked);
});

// 音效開關
sfxToggle.addEventListener('change', () => {
    AudioSystem.setSFXEnabled(sfxToggle.checked);
});

// 音量滑桿
volumeSlider.addEventListener('input', () => {
    const value = volumeSlider.value / 100;
    AudioSystem.setVolume(value);
    volumeValue.textContent = `${volumeSlider.value}%`;
});

window.addEventListener('keydown', (e) => {
    if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', ' '].includes(e.key)) {
        e.preventDefault();
    }
});
